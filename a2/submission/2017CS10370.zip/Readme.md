## ROBDD implementation
Submitted by Saksham Dhull (2017CS10370) for Course COL703 (Logic in Computer Science).

## How to use:
All required functions are implemented in BDD module. Call `n_queen` to get any satisfying result for given `n`. Call `n_queen_bdd` to obtain ROBDD for a given `n` 
